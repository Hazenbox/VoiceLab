# @jio/datavis-components

React component library for data visualization with Figma design token integration.

## Quick Links

- [Data Format Specification](./docs/DATA-FORMAT.md) - **Canonical data format for all charts**
- [Contributing Guide](./CONTRIBUTING.md) - Development workflow for creating/updating components
- [Changelog](./CHANGELOG.md) - Version history and release notes
- [Component Usage Guide](./src/markdown/ComponentUsageGuide.md) - Integration guide for consuming projects

## Installation

```bash
npm install @jio/datavis-components
```

## Quick Start

```tsx
import { VerticalBarChart } from "@jio/datavis-components";
import { ChartDataPoint } from "@jio/datavis-components/types";

// Canonical data format - see docs/DATA-FORMAT.md
const data: ChartDataPoint[] = [
  { id: "jan", category: "Jan", value: 120 },
  { id: "feb", category: "Feb", value: 180 },
  { id: "mar", category: "Mar", value: 90 },
];

<VerticalBarChart
  data={data}
  chartHeader={{ title: "Monthly Revenue" }}
  modes={{ colourMode: "Light", colourTheme: "MyJio" }}
/>;
```

## Accessibility

All chart components include built-in screen reader support (enabled by default):

```tsx
<VerticalBarChart
  data={data}
  chartHeader={{ title: "Revenue" }}
  accessibility={{
    enabled: true, // default
    dataTable: true, // hidden data table for screen readers
    summary: "auto", // auto-generated or custom string
  }}
/>
```

Screen readers will announce: _"bar chart titled 'Revenue'. Shows 3 data points. Values range from 90 to 180..."_

## TypeScript

All components are fully typed. Import types as needed:

```tsx
import type {
  // Canonical data types (recommended)
  ChartDataPoint,
  ChartSeriesDataPoint,
  TimeSeriesDataPoint,
  ChartData,
  ChartDataMeta,
  // Legacy types (for backward compatibility)
  DataPoint,
  MultiBarDataPoint,
  StackedBarDataPoint,
  LineSeriesData,
  // Config types
  ModesConfig,
  ChartLegendItem,
} from "@jio/datavis-components";
```

## Browser Support

- Chrome (last 2 versions)
- Firefox (last 2 versions)
- Safari (last 2 versions)
- Edge (last 2 versions)

## Development

```bash
npm install          # Install dependencies
npm run storybook    # Start Storybook
npm run build:lib    # Build library
npm test             # Run tests
```

## License

MIT

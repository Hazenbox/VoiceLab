# @jio/datavis-components

## Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added

#### Charts & Visualizations

- **Vertical multi-bar charts** — `VerticalMultiBar`, `VerticalMultiBarGroup`, `VerticalMultiBarChart` (up to 3 series per category with categorical color palette)
- **Vertical stacked bar charts** — `VerticalStackedBar`, `VerticalStackedBarGroup`, `VerticalStackedBarChart`
- **Horizontal bar charts** — `HorizontalBar`, `HorizontalBarGroup`, `HorizontalBarChart`
- **Horizontal stacked charts** — `HorizontalStackedBar`, `HorizontalStackedBarGroup`, `HorizontalStackedBarChart`
- **Horizontal butterfly charts** — `HorizontalButterflyBar`, `HorizontalButterflyBarGroup`, `HorizontalButterflyBarChart`
- **Line charts** — `PathGroup`, `LineChart` with multi-series support and hover interaction
- **Projection charts** — `ProjectionPathGroup`, `ProjectionLineChart` with confidence bands
- **Area charts** — `AreaGroup`, `AreaChart`
- **Donut charts** — `DonutPathGroup`, `DonutChart`
- **Histogram charts** — `HistogramGroup`, `HistogramChart`
- **Area heat maps** — `AreaHeatMapGroup`, `AreaHeatMapChart`
- **Clustered bubble charts** — `ClusteredBubbleGroup`, `ClusteredBubbleChart`
- **Lollipop charts** — `LollipopBar`, `LollipopBarGroup`, `LollipopBarChart`
- **Dumbbell charts** — `HorizontalDumbbellBar`, `HorizontalDumbbellBarGroup`, `HorizontalDumbbellChart`

#### Components

- **Legend system** — `ChartLegend`, `ChartKey`, `InlineChartKey`, `InlineChartKeyGroup`, `SequentialChartKey`
- **Data display** — `DataHead`, `DataLead`, `DataSupporting`, `SupportingLabel`, `DataDisplay`
- **DataCard** — KPI cards and metric displays, first component to implement the Appearance Chain pattern
- **AvgLine** — Horizontal average line via D3 mean calculation with `DataBadge` display; automatically inverts colourMode for badge visibility
- **HoverLine** — Interactive line chart hover states with vertical solid line and colored dots; uses SVG path sampling with `getPointAtLength()` + binary search for accurate curve tracking; works with any D3 curve interpolation
- **DataBadge** and **DataBadgeSemantic** — Value display badges with semantic color support
- **HoverBadge** — Shared hover badge component with `useHoverBadge` hook for reuse across all chart types; resolves `enterTransition`/`exitTransition` tokens from Figma; manages fade in/out animation timing; preserves badge position during fade-out
- **ChartAccessibility** — Screen reader wrapper with ARIA attributes (`role="figure"`, `aria-label`, `aria-describedby`), auto-generated natural language summaries, visually-hidden data tables, and statistics calculation (min, max, avg, trend detection)

#### Architecture & Patterns

- **Brand-first token architecture** — New "10 Brand" collection as the entry point for all token resolution, enabling future multi-brand support
- **Appearance Chain pattern** — Automatic text color contrast via hierarchical resolution: 1 Appearance → 2 Fill emphasis → 3 Background Level. When a container uses `fillEmphasis: "Bold"` (dark background), text tokens resolve to light colors; when `fillEmphasis: "Subtle"`, they resolve to dark colors
- **Organized Props Pattern** — Standard three-layer compound component props: Global Modes → Parent Props → Child Configs. Child component props grouped into named config objects. `LinearProgressBar` refactored as reference implementation
- **Hover transition tokens** — Motion tokens from Figma `hoverTransition` collection (`easing`, `duration`, `mode`); `mode` variable controls "11 Motion" collection for duration scale (Subtle = 135ms, Moderate = 200ms). Applied to `ShapeRect` and `VerticalBar` hover color transitions
- **Enter/exit transition tokens** — Separate Figma collections for `useHoverBadge` fade-in/fade-out animations, each with their own `easing`, `duration`, and `mode` variables
- **Canonical data format** — `ChartSeriesDataPoint` long-form format with transformation utilities (`toCanonical`, `fromWideFormat`, `fromLabelValue`, `fromNestedSegments`, `fromCategoriesSeries`, `toMultiBarData`, `toStackedBarData`, `toAreaGroupData`)
- **PathGroup hover interaction** — Added `showHoverLine` prop (default: `true`) and `onHover` callback returning `HoverData` object for tooltip integration

#### Infrastructure

- Professional library build with **tsup** (ESM + CJS + TypeScript declarations)
- **CI/CD pipeline** with GitHub Actions (lint, type-check, test, build, Storybook build/deploy, security audit)
- **Pre-commit hooks** with husky v9 and lint-staged (ESLint + Prettier on staged files)
- **Prettier** code formatting (design token JSON files excluded — auto-generated from Figma)
- **Jest testing** with accessibility checks via jest-axe; mocks for `window.matchMedia` and `ResizeObserver`
- **Changesets** for versioning and changelog automation (`@changesets/changelog-github`)
- **Cross-browser font system** — JioType variable fonts (woff2-variations, 63KB for all weights 100-900) with `@font-face` declarations and static woff2/woff fallbacks; `font-display: swap` for immediate text rendering
- **Performance optimizations** — O(1) name lookup (`nameMap`), resolution caching (`resolvedCache`), null caching for failed lookups, cache key generation via sorted mode string

### Fixed

- **D3 scale alignment** — YAxis ticks and ZeroLine were misaligned because YAxis was positioned from TOP while bars/ZeroLine positioned from BOTTOM. Changed YAxis to use `bottom: Xpx` positioning with the same D3 scale direction as all other chart elements
- **Safari font rendering** — Fonts now render correctly across all browsers with proper @font-face declarations using variable font format and static weight fallbacks
- **Font family token paths** — Corrected from `[Default]` to semantic variants (`[Title]`, `[Body]`, `[Label]`, `[Headline]`) matching Figma token structure
- **CI/CD platform issues** — Changed `npm ci` → `npm install` in GitHub Actions workflows (platform-specific rollup binaries: macOS lock file vs Linux runner). Removed `--coverage` from CI test command (`babel-plugin-istanbul` / `test-exclude` incompatibility with Node.js 20)
- Added `@rollup/rollup-linux-x64-gnu` and `@rollup/rollup-linux-x64-musl` to `optionalDependencies`
- Added `"typescript": "^5.0.0"` to `overrides` (resolves `react-scripts@5.0.1` peer dep conflict)

### Changed

- **Token path migration** for Brand-first architecture:
  - `Dimensions/Spacing/*` → `Dimensions/Spacings/*`
  - `Surfaces/Neutral/[Theme] High` → `Colour/on-Colour/High`
  - `Surfaces/Neutral/[Theme] Medium` → `Colour/on-Colour/Medium`
  - `Surfaces/Neutral/[Theme] Low` → `Colour/on-Colour/Low`
  - `Surfaces/Neutral/[Theme] Minimal` → `Colour/on-Colour/Minimal`
  - `Surfaces/Neutral/[Theme] Surface` → `Colour/Surface`
- All component `modes` interfaces updated with `Brand?: string` property

## [0.1.0] - 2026-01-27

### Added

- Initial component library with Figma design token integration
- **Charts**: VerticalBarChart
- **Components**: ChartHeader, ChartFooter, ChartTitle, ChartSubtitle, ChartBody
- **Building Blocks**: VerticalBar, VerticalBarGroup, YAxis, XAxis, ZeroLine, ShapeRect, ChartAxisTick
- **Utilities**: formatValue, formatNumber, formatPercentage, formatCurrency, formatLargeNumber
- Design token resolver (`figma-variables-resolver.js`) with `getVariableByName()`
- Multi-mode theming (Platform, Density, Theme, Colour Mode)
- Storybook documentation

### Architecture

- Brand-first token resolution hierarchy
- D3 scale synchronization for chart element alignment
- Organized Props Pattern for compound components
- Appearance Chain Pattern for automatic text contrast
